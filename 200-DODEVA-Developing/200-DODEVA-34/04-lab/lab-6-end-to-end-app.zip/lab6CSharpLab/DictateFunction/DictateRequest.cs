﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DictateFunction
{
    public class DictateRequest
    {
        public String voiceId { get; set; }
        public Note note { get; set; }
    }
}
